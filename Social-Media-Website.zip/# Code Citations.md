# Code Citations

## License: unknown
https://github.com/whitefoxx/tiny-projects/blob/c0d75e179a80957c5c7dcdbdb2b07430f033122f/office%20design/index.html

```
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" href="/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1.
```


## License: unknown
https://github.com/zerob13/zerob13.github.io/blob/42d1a9249ec4b8a81ced958690955c0e8e0602fe/_posts/2022-05-26-migrate-webpack-to-vite.md

```
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" href="/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1.
```

