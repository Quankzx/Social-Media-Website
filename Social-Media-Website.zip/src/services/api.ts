// Demo API client với Axios
import axios from 'axios';

const api = axios.create({
  baseURL: 'https://api.example.com',
  timeout: 10000,
});

// Request interceptor: attach auth token if present in localStorage (placeholder)
api.interceptors.request.use(
  (config) => {
    try {
      const token = localStorage.getItem('auth_token');
      if (token && config.headers) {
        config.headers['Authorization'] = `Bearer ${token}`;
      }
    } catch (e) {
      // ignore on server or when localStorage not available
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: basic error handling and logging
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // TODO: wire into centralized logger / Sentry
    // eslint-disable-next-line no-console
    console.error('API error', error?.response || error.message || error);
    return Promise.reject(error);
  }
);

export default api;
