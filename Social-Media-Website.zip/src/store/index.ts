// Demo cấu trúc store với Zustand
import { create } from 'zustand';

interface Post {
  id: string;
  title: string;
  content: string;
  date: string;
  network: 'Facebook' | 'TikTok' | 'YouTube' | 'Instagram';
  status: 'Đã đăng' | 'Lên lịch' | 'Nháp' | 'Đang xử lý' | 'Lỗi';
  platformId?: string; // id of the post on the platform
  mediaUrls?: string[];
  tags?: string[]; // for YouTube, Instagram
  music?: string; // for TikTok
  description?: string; // for YouTube
  hashtags?: string[]; // for Instagram, TikTok
}

interface Media {
  id: string;
  type: 'image' | 'video';
  url: string;
  name: string;
}

type Role = 'Admin' | 'Editor' | 'Creator' | 'Viewer';

interface Member {
  id: string;
  name: string;
  email: string;
  role: Role;
}

interface NotificationItem {
  id: string;
  title: string;
  message?: string;
  read?: boolean;
  timestamp: string;
}

interface AppState {
  user: any;
  setUser: (user: any) => void;
  theme: string;
  setTheme: (theme: string) => void;
  notification: string;
  setNotification: (msg: string) => void;
  posts: Post[];
  addPost: (post: Omit<Post, 'id'>) => void;
  updatePost: (id: string, post: Partial<Post>) => void;
  deletePost: (id: string) => void;
  media: Media[];
  addMedia: (media: Omit<Media, 'id'>) => void;
  deleteMedia: (id: string) => void;
  // RBAC & members
  members: Member[];
  addMember: (member: Omit<Member, 'id'>) => void;
  updateMemberRole: (id: string, role: Role) => void;
  removeMember: (id: string) => void;
  // Notifications
  notifications: NotificationItem[];
  pushNotification: (item: Omit<NotificationItem, 'id' | 'timestamp'>) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  // global loading/demo skeleton flag
  isAppLoading: boolean;
  setAppLoading: (v: boolean) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  user: null,
  setUser: (user) => set({ user }),
  theme: 'light',
  setTheme: (theme) => set({ theme }),
  notification: '',
  setNotification: (msg) => set({ notification: msg }),
  posts: [
    { id: '1', title: 'Bài Facebook 1', content: 'Nội dung bài 1', date: '2025-09-22', network: 'Facebook', status: 'Đã đăng', tags: ['social', 'media'], platformId: 'fb_1001' },
    { id: '2', title: 'Video TikTok', content: 'Nội dung video', date: '2025-09-23', network: 'TikTok', status: 'Lên lịch', music: 'Nhạc nền vui', hashtags: ['tiktok', 'viral'], platformId: 'tt_2002' },
    { id: '3', title: 'Shorts YouTube', content: 'Nội dung shorts', date: '2025-09-24', network: 'YouTube', status: 'Nháp', description: 'Mô tả chi tiết', tags: ['youtube', 'shorts'] },
    { id: '4', title: 'Ảnh Instagram', content: 'Nội dung ảnh', date: '2025-09-25', network: 'Instagram', status: 'Đã đăng', hashtags: ['instagram', 'photo'], platformId: 'ig_4004' },
  ],
  addPost: (post) => set((state) => ({ posts: [...state.posts, { ...post, id: Date.now().toString() }] })),
  updatePost: (id, updates) => set((state) => ({
    posts: state.posts.map(p => p.id === id ? { ...p, ...updates } : p)
  })),
  deletePost: (id) => set((state) => ({ posts: state.posts.filter(p => p.id !== id) })),
  media: [
    { id: '1', type: 'image', url: 'https://picsum.photos/seed/1/200', name: 'image1.jpg' },
    { id: '2', type: 'image', url: 'https://picsum.photos/seed/2/200', name: 'image2.jpg' },
    { id: '3', type: 'video', url: 'https://www.w3schools.com/html/mov_bbb.mp4', name: 'video.mp4' },
    { id: '4', type: 'image', url: 'https://picsum.photos/seed/3/200', name: 'image3.jpg' },
  ],
  addMedia: (media) => set((state) => ({ media: [...state.media, { ...media, id: Date.now().toString() }] })),
  deleteMedia: (id) => set((state) => ({ media: state.media.filter(m => m.id !== id) })),
  // members & RBAC
  members: [
    { id: 'm1', name: 'Alice Admin', email: 'alice@example.com', role: 'Admin' },
    { id: 'm2', name: 'Eddie Editor', email: 'eddie@example.com', role: 'Editor' },
    { id: 'm3', name: 'Carla Creator', email: 'carla@example.com', role: 'Creator' },
    { id: 'm4', name: 'Vera Viewer', email: 'vera@example.com', role: 'Viewer' },
  ],
  addMember: (member) => set((state) => ({ members: [...state.members, { ...member, id: Date.now().toString() }] })),
  updateMemberRole: (id, role) => set((state) => ({ members: state.members.map(m => m.id === id ? { ...m, role } : m) })),
  removeMember: (id) => set((state) => ({ members: state.members.filter(m => m.id !== id) })),
  // notifications
  notifications: [],
  pushNotification: (item) => set((state) => ({ notifications: [{ ...item, id: Date.now().toString(), timestamp: new Date().toISOString(), read: false }, ...state.notifications] })),
  markNotificationRead: (id) => set((state) => ({ notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n) })),
  clearNotifications: () => set({ notifications: [] }),
  // global loading flag
  isAppLoading: false,
  setAppLoading: (v: boolean) => set({ isAppLoading: v }),
}));
